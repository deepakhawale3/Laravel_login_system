<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Property;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
class PropertyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $customerId = Auth::id();
        $properties = Property::where('customer_id', $customerId)->get();
        return view('customer.property.index', compact('properties'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('customer.property.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    
     public function store(Request $request)
     {
         $request->validate([
             'type' => 'required|string',
             'location' => 'required|string',
             'city' => 'required|string',
             'size' => 'required|integer',
             'images' => 'nullable|image|max:2048', // Assuming images are of type 'image' with max size 2048 KB (2 MB)
             'price' => 'required|numeric',
         ]);
     
         $validatedData = $request->validate([
             'type' => 'required|string',
             'location' => 'required|string',
             'city' => 'required|string',
             'size' => 'required|integer',
             'price' => 'required|numeric',
         ]);
     
         $imageName = null;
         if ($request->hasFile('images')) {
             $imageName = time() . '_' . $request->images->getClientOriginalName();
             $request->images->move(public_path('images'), $imageName);
         }
     
         $property = new Property([
             'type' => $validatedData['type'],
             'location' => $validatedData['location'],
             'city' => $validatedData['city'],
             'size' => $validatedData['size'],
             'images' => $imageName,
             'price' => $validatedData['price'],
             'customer_id' => Auth::id(),
         ]);
         $property->save();
     
         return redirect()->route('properties.index')
             ->with('success', 'Property created successfully.');
     }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $property = Property::find($id);

        // Check if the property belongs to the currently logged-in user
        if ($property->customer_id !== Auth::id()) {
            // Redirect the user or return an error response
            return redirect()->route('properties.index')->with('error', 'You are not authorized to edit this property.');
        }

        return view('customer.property.edit', compact('property'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    

    public function update(Request $request, $id)
    {
        $request->validate([
            'type' => 'required|string',
            'location' => 'required|string',
            'city' => 'required|string',
            'size' => 'required|integer',
            'images' => 'nullable|image|max:2048', // Assuming images are of type 'image' with max size 2048 KB (2 MB)
            'price' => 'required|numeric',
        ]);

        $property = Property::find($id);

        $property->type = $request->type;
        $property->location = $request->location;
        $property->city = $request->city;
        $property->size = $request->size;
        $property->price = $request->price;

        if ($request->hasFile('images')) {
            // Delete previous image if it exists
            if ($property->images) {
                $imagePath = public_path('images') . '/' . $property->images;
                if (file_exists($imagePath)) {
                    unlink($imagePath);
                }
            }

            // Store new image
            $imageName = time() . '_' . $request->images->getClientOriginalName();
            $request->images->move(public_path('images'), $imageName);
            $property->images = $imageName;
        }

        $property->save();

        return redirect()->route('properties.index')
            ->with('success', 'Property updated successfully');
    }




    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $property = Property::find($id);

        if ($property) {
            $property->delete();
            // You can return a success message or redirect the user to another page.
            return redirect()->back()->with('success', 'Property deleted successfully.');
        } else {
            // You can return an error message or redirect the user to another page.
            return redirect()->back()->with('error', 'Property not found.');
        }
    }
}
