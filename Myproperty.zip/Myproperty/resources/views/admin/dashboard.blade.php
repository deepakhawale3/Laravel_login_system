@extends('admin.layouts.app')

@section('content')
<div class="container">
    

    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card text-center">
                <div class="card-header">Total Number of Properties</div>
                <div class="card-body">
                    <h3>{{ $totalProperties }}</h3>
                    <a class="btn btn-primary mt-3" href="{{ route('allproperty.index') }}">View</a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card text-center">
                <div class="card-header">Total Number of Customers</div>
                <div class="card-body">
                    <h3>{{ $totalCustomers }}</h3>
                    <a class="btn btn-primary mt-3" href="{{ route('allcustomer.index') }}">View</a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
