@extends('admin.layouts.app')

@section('content')
    <div class="container">
        <div class="card">
            <div class="card-header">All Properties</div>
            <div class="card-body">
                
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">Sr. No.</th>
                            <th scope="col">Customer Name</th>
                            <th scope="col">Type</th>
                            <th scope="col">Location</th>
                            <th scope="col">City</th>
                            <th scope="col">Size</th>
                            <th scope="col">Price</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php $count = 1 @endphp
                        @foreach ($properties as $property)
                            <tr>
                                <td>{{ $count++ }}</td>
                                <td>{{ $property->user->name }}</td>
                                <td>{{ $property->type }}</td>
                                <td>{{ $property->location }}</td>
                                <td>{{ $property->city }}</td>
                                <td>{{ $property->size }}</td>
                                <td>{{ $property->price }}</td>
                                <td>
                                    <form id="delete-form-{{ $property->id }}" action="{{ route('allproperty.destroy', $property->id) }}" method="POST">
                                        @csrf
                                        @method('DELETE')
                                        <button type="button" class="btn btn-danger" onclick="confirmPropertyDelete({{ $property->id }})">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<!-- Include SweetAlert2 script -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    function confirmPropertyDelete(propertyId) {
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('delete-form-' + propertyId).submit();
            }
        });
    }

    @if(session('success'))
        Swal.fire({
            title: 'Deleted!',
            text: '{{ session('success') }}',
            icon: 'success',
            confirmButtonText: 'OK'
        });
    @endif
</script>
@endsection
