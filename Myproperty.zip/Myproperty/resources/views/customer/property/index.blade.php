@extends('customer.layouts.app')

@section('content')
    <div class="container">
        <div class="row mb-3">
            <div class="col">
                <a href="{{ route('properties.create') }}" class="btn btn-success">Add Property</a>
            </div>
        </div>
        <div class="row row-cols-1 row-cols-md-4 g-4">
            @foreach ($properties as $property)
                <div class="col">
                    <div class="card">
                        @if ($property->images)
                            <img src="{{ asset('public/images/' . $property->images) }}" class="card-img-top img-fluid" alt="Property Image" style="max-width: 100%; height: auto; max-height: 200px; width: 100%;">
                        @endif
                        <div class="card-body">
                            <h5 class="card-title">{{ $property->type }}</h5>
                            <p class="card-text">Location: {{ $property->location }}</p>
                            <p class="card-text">City: {{ $property->city }}</p>
                            <p class="card-text">Size: {{ $property->size }}</p>
                            <p class="card-text">Price: {{ $property->price }}</p>
                            <a href="{{ route('properties.edit', $property->id) }}" class="btn btn-primary">Edit</a>
                            <form id="delete-form-{{ $property->id }}" action="{{ route('properties.destroy', $property->id) }}" method="POST" style="display: inline-block;">
                                @csrf
                                @method('DELETE')
                                <button type="button" class="btn btn-danger" onclick="confirmPropertyDeletion({{ $property->id }})">Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>

    <!-- Include SweetAlert2 script -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        @if(session('success'))
        Swal.fire({
            title: 'Success!',
            text: '{{ session('success') }}',
            icon: 'success',
            confirmButtonText: 'OK'
        });
    @endif
    </script>
    <script>
        function confirmPropertyDeletion(propertyId) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('delete-form-' + propertyId).submit();
                }
            });
        }
    </script>
@endsection
