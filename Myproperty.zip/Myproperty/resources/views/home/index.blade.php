@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        @foreach ($properties as $property)
            <div class="col-md-3">
                <div class="card">
                    <img src="public/images/{{ $property->images }}" style="width: 100%; height: 200px; object-fit: cover;" alt="Property Image">
                    <div class="card-body">
                        <h5 class="card-title">{{ $property->type }}</h5>
                        <p class="card-text">Location: {{ $property->location }}</p>
                        <!-- Add other property details here -->
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>
@endsection
