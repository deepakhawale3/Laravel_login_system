

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header">All Properties</div>
            <div class="card-body">
                
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">Sr. No.</th>
                            <th scope="col">Customer Name</th>
                            <th scope="col">Type</th>
                            <th scope="col">Location</th>
                            <th scope="col">City</th>
                            <th scope="col">Size</th>
                            <th scope="col">Price</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $count = 1 ?>
                        <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($count++); ?></td>
                                <td><?php echo e($property->user->name); ?></td>
                                <td><?php echo e($property->type); ?></td>
                                <td><?php echo e($property->location); ?></td>
                                <td><?php echo e($property->city); ?></td>
                                <td><?php echo e($property->size); ?></td>
                                <td><?php echo e($property->price); ?></td>
                                <td>
                                    <form id="delete-form-<?php echo e($property->id); ?>" action="<?php echo e(route('allproperty.destroy', $property->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="button" class="btn btn-danger" onclick="confirmPropertyDelete(<?php echo e($property->id); ?>)">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<!-- Include SweetAlert2 script -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    function confirmPropertyDelete(propertyId) {
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('delete-form-' + propertyId).submit();
            }
        });
    }

    <?php if(session('success')): ?>
        Swal.fire({
            title: 'Deleted!',
            text: '<?php echo e(session('success')); ?>',
            icon: 'success',
            confirmButtonText: 'OK'
        });
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Myproperty\resources\views/admin/allproperty/index.blade.php ENDPATH**/ ?>