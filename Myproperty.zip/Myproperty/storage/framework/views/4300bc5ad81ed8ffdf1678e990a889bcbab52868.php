

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
                <div class="card">
                    <img src="public/images/<?php echo e($property->images); ?>" style="width: 100%; height: 200px; object-fit: cover;" alt="Property Image">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($property->type); ?></h5>
                        <p class="card-text">Location: <?php echo e($property->location); ?></p>
                        <!-- Add other property details here -->
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Myproperty\resources\views/home/index.blade.php ENDPATH**/ ?>