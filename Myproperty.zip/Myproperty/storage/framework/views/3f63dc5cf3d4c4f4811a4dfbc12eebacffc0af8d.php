

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row mb-3">
            <div class="col">
                <a href="<?php echo e(route('properties.create')); ?>" class="btn btn-success">Add Property</a>
            </div>
        </div>
        <div class="row row-cols-1 row-cols-md-4 g-4">
            <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="card">
                        <?php if($property->images): ?>
                            <img src="<?php echo e(asset('public/images/' . $property->images)); ?>" class="card-img-top img-fluid" alt="Property Image" style="max-width: 100%; height: auto; max-height: 200px; width: 100%;">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($property->type); ?></h5>
                            <p class="card-text">Location: <?php echo e($property->location); ?></p>
                            <p class="card-text">City: <?php echo e($property->city); ?></p>
                            <p class="card-text">Size: <?php echo e($property->size); ?></p>
                            <p class="card-text">Price: <?php echo e($property->price); ?></p>
                            <a href="<?php echo e(route('properties.edit', $property->id)); ?>" class="btn btn-primary">Edit</a>
                            <form id="delete-form-<?php echo e($property->id); ?>" action="<?php echo e(route('properties.destroy', $property->id)); ?>" method="POST" style="display: inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="button" class="btn btn-danger" onclick="confirmPropertyDeletion(<?php echo e($property->id); ?>)">Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <!-- Include SweetAlert2 script -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        <?php if(session('success')): ?>
        Swal.fire({
            title: 'Success!',
            text: '<?php echo e(session('success')); ?>',
            icon: 'success',
            confirmButtonText: 'OK'
        });
    <?php endif; ?>
    </script>
    <script>
        function confirmPropertyDeletion(propertyId) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('delete-form-' + propertyId).submit();
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Myproperty\resources\views/customer/property/index.blade.php ENDPATH**/ ?>